module.exports = {
    database: {
        host: process.env.DB_HOST,
        user: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_DATABASE
    }
}
// module.exports = {
//     database: {
//         host: 'localhost',
//         user: 'root',
//         password: '',
//         database: 'gallery'
//     }
// }

// DB_DATABASE = badofnhtlngrjlwg8xcz
// DB_HOST = badofnhtlngrjlwg8xcz-mysql.services.clever-cloud.com
// DB_PASSWORD = f8vkhHV1XAIXV0ItHnHH
// DB_USERNAME = ugtvochftojd0nno